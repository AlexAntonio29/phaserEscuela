<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.4" name="[A]Wall-Up_pipo" tilewidth="32" tileheight="32" tilecount="96" columns="8">
 <image source="[A]Wall-Up_pipo.png" width="256" height="384"/>
</tileset>
